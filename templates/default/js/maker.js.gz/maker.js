
var json;
var page = 0;
var obj;
var app;
var pages;

function page(){
    obj = JSON.parse(json);
    app = obj.app;
    pages = obj.menu.length;
    menu();
    content();
}

function parse(){
    var x = new XMLHttpRequest();
    x.open("GET", "/echo", true);
    x.onload = function () {
        json = x.responseText;
        page();
        getElementById("debug").innerHTML = json;
    }
    x.send(null);
}

function new_page(p){
    page = p;
    menu();
    content();
}

function inner(id, content){
    document.getElementById(id).innerHTML += content;
}

function menu_item(name, current, p){
    if (!current)
        return "<li class=\"pure-menu-item\" onclick=\"new_page(" + p + ")\"><a href=\"#\" class=\"pure-menu-link\">" + name + "</a></li>";
    else
        return "<li class=\"pure-menu-item menu-item-divided pure-menu-selected\" onclick=\"new_page(" + p + ")\"><a href=\"#\" class=\"pure-menu-link\">" + name + "</a></li>";
}

function menu(){
    var content = "<div class=\"pure-menu\"><a class=\"pure-menu-heading\" href=\"#\">" + app + "</a><ul class=\"pure-menu-list\">";
    for(var i = 0; i < pages; i++){
        var current;
        if(page == i) current = true;
        else current = false;
        content += menu_item(obj.menu[i], current, i);
    }
    content += "</ul></div>";
    document.getElementById("menu").innerHTML = content;
}

function content(){
    document.getElementById("main").innerHTML = "";
    var content = "<div class=\"header\"><h1>" + obj.menu[page] + "</h1></div>";
    content += "<div class=\"content\">";
    content += "<form class=\"pure-form pure-form-stacked\">";
    content += "<fieldset>";
    content += "<div class=\"pure-g\">";

    var items = obj.content[page].length;
    for(var i = 0; i < items; i++){
        content += content_item(obj.content[page][i], i);
    }

    content += "</div>";
    content += "</fieldset>";
    content += "</form>";
    content += "</div>";
    document.getElementById("main").innerHTML = content;
}

function content_item(item, i){


    var content = "<div class=\"pure-u-1 pure-u-md-1-3\">";

    var html = item.html;

    if (html == "input" && item.type == 'range') content += "<label id=\"" + item.id + "-val\">" + item.label + " " + item.value + "</label>";
    else if (item.type == "checkbox") content += "<label class=\"pure-checkbox\">";
    else content += "<label>" + item.label + "</label>";

    switch (html) {
        case "input":
            content += "<input ";
            if (typeof item.type == 'string') content += "type=\"" + item.type + "\"";
            if (typeof item.id == 'string') content += "id=\"" + item.id + "\"";
            if (typeof item.name == 'string') content += "name=\"" + item.name + "\"";
            if (typeof item.min == 'string') content += "min=\"" + item.min + "\"";
            if (typeof item.max == 'string') content += "max=\"" + item.max + "\"";
            if (typeof item.step == 'string') content += "step=\"" + item.step + "\"";
            if (typeof item.value == 'string') content += "value=\"" + item.value + "\"";
            if (typeof item.placeholder == 'string') content += "placeholder=\"" + item.placeholder + "\"";
            if (item.type != "checkbox") content += "class=\"pure-u-24-24\"";
            if (item.type == "checkbox" && item.value == 'true') content += " checked ";
            content += "oninput=\"data('" + item.type + "', this.id, this.value, '" + item.label + "', " + page + ", " + i + ")\"";
            content += ">";
            if (item.type == "checkbox") content += "&nbsp" + item.label + "</label>";
            break;

        case "select":
            content += "<select ";
            if (typeof item.id == 'string') content += "id=\"" + item.id + "\"";
            if (typeof item.name == 'string') content += "name=\"" + item.name + "\"";
            if (typeof item.value == 'string') content += "value=\"" + item.value + "\"";
            content += "class=\"pure-u-24-24\"";
            content += "oninput=\"data(" + item.type + ", this.id, this.value, '" + item.label + "', '" + page + "', '" + i + "')\"";
            content += ">";
            for(var i = 0; i < item.options.length; i++){
                if (item.options[i] == item.value) content += "<option selected>";
                else content += "<option>";
                content += item.options[i];
                content += "</option>";
            }
            content += "</select>";
            break;
    
        default:
            break;
    }
    content += "</div>";
    return content;
}

function data(type, id, value, label, page, i){
    if (type == "range") document.getElementById(id + "-val").innerHTML = label + ":&nbsp" + value;

    if (type == "checkbox"){
        var chbox=document.getElementById(id);
        if (chbox.checked) value = "true";
        else  value = "false";
    }
    obj.content[page][i].value = value;
}
